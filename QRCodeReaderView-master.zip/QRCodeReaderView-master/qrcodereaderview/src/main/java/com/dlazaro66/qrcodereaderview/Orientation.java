package com.dlazaro66.qrcodereaderview;

public enum Orientation {
  PORTRAIT, LANDSCAPE
}
