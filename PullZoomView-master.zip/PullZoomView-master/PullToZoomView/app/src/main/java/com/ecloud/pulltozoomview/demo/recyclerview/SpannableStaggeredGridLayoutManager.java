package com.ecloud.pulltozoomview.demo.recyclerview;

import android.support.v7.widget.RecyclerView;

/**
 * Created by manishdeora on 14/05/15.
 */
public class SpannableStaggeredGridLayoutManager extends RecyclerView.LayoutManager{


    @Override
    public RecyclerView.LayoutParams generateDefaultLayoutParams() {
        return null;
    }
}
