package com.viewpagerindicator;

/**
 * Created by Ali Muzaffar on 5/02/2016.
 */
public interface LoopingPagerAdapter {
    int getRealCount();
}
