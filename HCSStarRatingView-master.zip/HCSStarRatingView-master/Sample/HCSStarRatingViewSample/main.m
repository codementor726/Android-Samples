//
//  main.m
//  HCSStarRatingViewSample
//
//  Created by Hugo Sousa on 10/02/15.
//  Copyright (c) 2015 Hugo Sousa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
