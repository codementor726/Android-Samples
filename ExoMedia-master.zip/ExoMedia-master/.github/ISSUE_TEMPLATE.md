- [ ] I have verified there are no duplicate active or recent bugs, questions, or requests

###### Include the following:
 - ExoMedia version: `4.0.0`
 - Device OS version: `7.0`
 - Devide Manufacturer: `Google`
 - Device Name: `Pixel XL`
 
###### Reproduction Steps
 0.  

###### Expected Result

###### Actual Result
