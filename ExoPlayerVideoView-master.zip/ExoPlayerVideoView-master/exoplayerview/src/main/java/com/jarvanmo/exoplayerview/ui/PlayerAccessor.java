package com.jarvanmo.exoplayerview.ui;

import com.google.android.exoplayer2.Player;

/**
 * Created by mo on 18-2-5.
 * 剑气纵横三万里 一剑光寒十九洲
 */

public interface PlayerAccessor {

    Player attachPlayer();
}
