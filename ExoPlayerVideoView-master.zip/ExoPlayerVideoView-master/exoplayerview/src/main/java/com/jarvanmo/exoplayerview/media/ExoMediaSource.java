package com.jarvanmo.exoplayerview.media;

/**
 * Created by mo on 18-1-11.
 * 剑气纵横三万里 一剑光寒十九洲
 */

public interface ExoMediaSource {

    String getUrl();
    String getDisplayName();
}
