package it.neokree.materialnavigationdrawer.elements.listeners;

import it.neokree.materialnavigationdrawer.elements.MaterialSection;

/**
 * Created by neokree on 08/11/14.
 */
public interface MaterialSectionListener {

    public void onClick(MaterialSection section);
}
