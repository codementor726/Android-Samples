package com.pierfrancescosoffritti.youtubeplayer.utils;

public interface Callable {
    void call();
}
