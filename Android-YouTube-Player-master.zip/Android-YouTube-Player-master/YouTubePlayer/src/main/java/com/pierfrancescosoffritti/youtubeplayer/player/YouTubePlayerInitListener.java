package com.pierfrancescosoffritti.youtubeplayer.player;

public interface YouTubePlayerInitListener {
    void onInitSuccess(YouTubePlayer youTubePlayer);
}
