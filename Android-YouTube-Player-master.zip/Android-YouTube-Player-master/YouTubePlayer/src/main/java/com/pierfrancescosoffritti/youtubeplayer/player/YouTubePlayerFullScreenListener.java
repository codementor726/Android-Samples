package com.pierfrancescosoffritti.youtubeplayer.player;

public interface YouTubePlayerFullScreenListener {
    void onYouTubePlayerEnterFullScreen();
    void onYouTubePlayerExitFullScreen();
}
