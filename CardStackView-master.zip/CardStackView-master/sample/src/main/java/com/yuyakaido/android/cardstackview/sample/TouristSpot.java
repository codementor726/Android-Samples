package com.yuyakaido.android.cardstackview.sample;

public class TouristSpot {
    public String name;
    public String city;
    public String url;

    public TouristSpot(String name, String city, String url) {
        this.name = name;
        this.city = city;
        this.url = url;
    }
}
