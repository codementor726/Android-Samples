package com.yuyakaido.android.cardstackview;

public enum StackFrom {
    Bottom, Top;
    public static final StackFrom DEFAULT = Top;
}
