package com.yuyakaido.android.cardstackview.internal;

public enum Quadrant {
    TopLeft, TopRight, BottomLeft, BottomRight
}
