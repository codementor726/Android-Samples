package com.irontec.axier.mvvmexample.model

import java.util.*

/**
 * Created by oneil on 28/07/2017.
 */

class Article {

    var title: String? = null
    var subtitle: String? = null
    var excerpt: String? = null
    var date: Date? = null
}
